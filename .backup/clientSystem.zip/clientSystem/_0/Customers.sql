-- Database export via SQLPro (https://www.sqlprostudio.com/allapps.html)
-- Exported by icepitproductions at 03-02-2022 21:40.
-- WARNING: This file may contain descructive statements such as DROPs.
-- Please ensure that you are running the script at the proper location.


-- BEGIN TABLE Customers
DROP TABLE IF EXISTS Customers;
CREATE TABLE `Customers` (
  `ClientID` varchar(15) NOT NULL,
  `BandName` varchar(40) NOT NULL,
  `Email` varchar(60) DEFAULT NULL,
  `Phone` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`ClientID`),
  KEY `BandName` (`BandName`),
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Inserting 93 rows into Customers
-- Insert batch #1
INSERT INTO Customers (ClientID, BandName, Email, Phone) VALUES
('Hurk', 'Fettyville', 'Email@mail.com', '302-555-55555')

-- END TABLE Customers
