DECLARE @json NVARCHAR(MAX);
SET @json = N`{
                [
                    {
                        "Artist": "NewArtist"
                    }
                ]
            }'
select *
from OPENJSON(json, '$.CUSTOMERS')
with (
    id int '$.CUSTOMER.custid',
    name nvarchar(50) '$.CUSTOMER.name',
    hhi varchar(50) '$.CUSTOMER.demographics.hhi',
    dob date '$.CUSTOMER.dob'