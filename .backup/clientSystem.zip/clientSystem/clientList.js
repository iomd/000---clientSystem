//
const clientList = [
  {
    name: "J.Friz",
    bandName: "Baladon",
    email: "",
    genre: "Hip Hop",
    clientSince: "2003",
    recentProject:
    {
      albumName: "",
      albumYear: "",
    },
    photo: "img.file"

  },
  {
    name: "Sin Kattes",
    bandName: "Baladon",
    email: "",
    genre: "Hip Hop",
    clientSince: "2004",
    recentProject:
    {
      albumName: "",
      albumYear: "",
    },
    photo: "img.file"
  },
  {
    name: "Hurk",
    bandName: "Fettyville",
    email: "",
    genre: "Hip Hop",
    clientSince: "2011",
    recentProject:
    {
      albumName: "No Homage",
      albumYear: "2022",
    },
    photo: "img.file"
  },
  {
    name: "Gate",
    bandName: "Fettyville",
    email: "",
    genre: "Trap",
    clientSince: "2013",
    recentProject:
    {
      albumName: "",
      albumYear: "",
    },
    photo: "img.file"
  },
  {
    name: "Mark Irvin",
    bandName: "",
    email: "",
    genre: "R&B",
    clientSince: "2015",
    recentProject:
    {
      albumName: "",
      albumYear: "",
    },
    photo: "img.file"
  },
  {
    name: "Melek",
    bandName: "",
    email: "",
    genre: "R&B",
    clientSince: "2016",
    recentProject:
    {
      albumName: "",
      albumYear: "",
    },
    photo: "img.file"
  }
];

//
function clientTemplate(client) {
  return `
    <div class="client">
    <img class="client-photo" src="${client.photo}">
    <h2 class="client-name">${client.name} <span class="bandName">(${client.bandName})</span></h2>
    <p class="clientSince">Since: (${client.clientSince})</p><br>
    <p class="email">Email: ${client.email}</p><br>
    <p class="genre">Genre(s): ${client.genre}</p><br>
    <p class="recentProject">${client.recentProject.albumName} <span class="bandName">(${client.recentProject.albumYear})</span></p>
    </div>
  `;
}

//
document.getElementById("app").innerHTML = `
  <h1 class="app-title">Clients (${clientList.length} results)</h1>
  ${clientList.map(clientTemplate).join("")}
  <p class="footer">These ${clientList.length} Clients have been<br>Engineered by IOMD<br> Icepit Productions<br>Since 2003 - Current Date<p>
  `;
